# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
import bpy
import bpy_extras
import os

from bpy.props import StringProperty, BoolProperty 
from bpy_extras.io_utils import ImportHelper 
from bpy.types import Operator

bl_info = {
    "name" : "UgcToolForEERIE2",
    "author" : "UreaSoft",
    "description" : "",
    "blender" : (2, 80, 0),
    "version" : (0, 0, 1),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}
classes = []
mixamorig='mixamorig:'
leftBoneMark="Left"
rightBoneMark="Right"
leftBoneBlender=".L"
rightBoneBlender=".R"
replaceHandGroup=["手首","人指１","人指２","人指３","小指１","小指２","小指３","中指１","中指２","中指３","薬指１","薬指２","薬指３","親指０","親指１","親指２"]
targetHandGroup=["Hand","HandIndex1","HandIndex2","HandIndex3","HandPinky1","HandPinky2","HandPinky3","HandMiddle1","HandMiddle2","HandMiddle3","HandRing1","HandRing2","HandRing3","HandThumb1","HandThumb2","HandThumb3"]

replaceGroup=["下半身/腰","上半身","上半身1","上半身2/胸","首","頭/Hair/hair/髪/目"]
replaceMirrorGroup=["肩","腕","ひじ/手捩","足D","ひざD","足首","足先"]
targetGroup=["Hips","Spine","Spine1","Spine2","Neck","Head"]
targetMirrorGroup=["Shoulder","Arm","ForeArm","UpLeg","Leg","Foot","ToeBase"]

bpy.types.Scene.originalBoneMark=bpy.props.StringProperty(name="originalBoneMark",default=".L")
bpy.types.Scene.targetBoneMark=bpy.props.StringProperty(name="targetBoneMark",default=".R")

class Eerie_OT_MirrorMesh(bpy.types.Operator):
    bl_idname ="eerie.mirror_mesh"
    bl_label="mirror mesh of eerie2 arm"

    def execute(self, context):
        src_obj = bpy.context.active_object
        src_obj.select_set(False)
        new_obj = src_obj.copy()
        new_obj.data = src_obj.data.copy()
        new_obj.animation_data_clear()
        context.collection.objects.link(new_obj)
        new_obj.scale = (-1, 1, 1)
        new_obj.select_set(True)
        bpy.ops.object.transform_apply(scale=True)
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        
        vgs = [vg for vg in new_obj.vertex_groups
            if vg.name.find(context.scene.targetBoneMark) != -1]
        while(vgs):
            new_obj.vertex_groups.remove(vgs.pop())

        for g in new_obj.vertex_groups:
            g.name=g.name.replace(context.scene.originalBoneMark, context.scene.targetBoneMark)
        return {"FINISHED"}
classes.append(Eerie_OT_MirrorMesh)

class Eerie_OT_MirrorArmatureOn(bpy.types.Operator):
    bl_idname="eerie.mirror_armature_on"
    bl_label="add blender suffix to armature"
    def execute(self, context):
        src_obj = bpy.context.active_object
        len0=mixamorig.__len__()
        lenR=rightBoneMark.__len__()
        lenL=leftBoneMark.__len__()
        for bone in  src_obj.data.bones:
            n = bone.name
            if mixamorig in n:
                if leftBoneMark in n:
                    bone.name = n[len0+lenL:]+".L"
                elif rightBoneMark in n:
                    bone.name = n[len0+lenR:]+".R"
                else :
                    continue
        return{"FINISHED"}
classes.append(Eerie_OT_MirrorArmatureOn)

class Eerie_OT_GroupsConvert(bpy.types.Operator):
    bl_idname="eerie.groups_convert"
    bl_label="convert mmd vertex groups into game vertex groups"

    def convert(self,groupId,targetId):
        vertex_groups = bpy.context.active_object.vertex_groups
        group=vertex_groups[groupId]
        targetGroup=vertex_groups[targetId]
        for id, vert in enumerate(bpy.context.active_object.data.vertices):
            available_groups = [v_group_elem.group for v_group_elem in vert.groups]
            newWeight=0
            oldWeight=0
            if group.index in available_groups:
                newWeight = group.weight(id)
            if targetGroup.index in available_groups:
                oldWeight = targetGroup.weight(id)
            if newWeight>0:
                if newWeight>oldWeight:
                    if oldWeight>0:
                        targetGroup.add([id], newWeight ,'REPLACE')
                    else:
                        targetGroup.add([id], newWeight ,'ADD')
    
    def execute(self, context):
        vertex_groups = bpy.context.active_object.vertex_groups
        for group in vertex_groups:
            if mixamorig in group.name:
                self.report({"INFO"},"Has already been converted")
                return {"FINISHED"}
        global targetGroup
        global targetMirrorGroup
        global replaceGroup
        global replaceMirrorGroup
        targetGroupList=[-1]*(len(targetGroup))
        targetLeftGroupList=[-1]*(len(targetMirrorGroup))
        targetRightGroupList=[-1]*(len(targetMirrorGroup))
        #hand groups
        i=0
        while i<len(replaceHandGroup):
            for group in vertex_groups:
                if replaceHandGroup[i] in group.name:
                    if leftBoneBlender in  group.name:
                        group.name=mixamorig+leftBoneMark+targetHandGroup[i]
                        continue
                    elif rightBoneBlender in  group.name:
                        group.name=mixamorig+rightBoneMark+targetHandGroup[i]
                        continue
            i=i+1
        
        #new groups
        i=0
        while i<len(targetGroup):
            g=vertex_groups.new( name = mixamorig+targetGroup[i])
            targetGroupList[i]=g.index
            i=i+1
        i=0
        while i<len(targetMirrorGroup):
            g=vertex_groups.new( name =  mixamorig+leftBoneMark+targetMirrorGroup[i] )
            targetLeftGroupList[i]=g.index
            g=vertex_groups.new( name =  mixamorig+rightBoneMark+targetMirrorGroup[i] )
            targetRightGroupList[i]=g.index
            i=i+1
        
        #convert
        i=0
        while i<len(replaceGroup):
            groupNames= replaceGroup[i].split('/')
            for oneGroup in groupNames:
                for group in vertex_groups:
                    find=False
                    if i<2 or i==4:
                        if oneGroup==group.name:
                            find=True
                    elif oneGroup in group.name:
                        find=True
                    if find:
                        self.convert(group.index,targetGroupList[i])
            i=i+1
        i=0
        while i<len(replaceMirrorGroup):
            groupNames= replaceMirrorGroup[i].split('/')
            for oneGroup in groupNames:
                for group in vertex_groups:
                    if oneGroup in group.name:
                        if leftBoneBlender in group.name:
                            self.convert(group.index,targetLeftGroupList[i])
                        elif rightBoneBlender in group.name:
                            self.convert(group.index,targetRightGroupList[i])
            i=i+1
        
        for group in vertex_groups:
            if not mixamorig in group.name:
                vertex_groups.remove(group)
        
        return{"FINISHED"}
classes.append(Eerie_OT_GroupsConvert)

class Eerie_OT_MirrorArmatureOff(bpy.types.Operator):
    bl_idname="eerie.mirror_armature_off"
    bl_label="remove blender suffix to armature"
    def execute(self, context):
        src_obj = bpy.context.active_object
        len0=leftBoneBlender.__len__()
        for bone in  src_obj.data.bones:
            n = bone.name
            if leftBoneBlender in n:
                n=n[:-len0]
                bone.name=mixamorig+leftBoneMark+n
                continue
            elif rightBoneBlender in n:
                n=n[:-len0]
                bone.name=mixamorig+rightBoneMark+n
                continue
            else :
                continue
        return{"FINISHED"}
classes.append(Eerie_OT_MirrorArmatureOff)

class Eerie_PT_view3D(bpy.types.Panel):
    bl_idname="Eerie_ugc_pt_view3d"
    bl_label="eerie2 ugc tool"
    bl_category="EERIE2"
    bl_space_type="VIEW_3D"
    bl_region_type="UI"
    bl_context="objectmode"

    def draw(self, context):
        layout=self.layout
        col=layout.column()
        col.label(text='arm mesh mirror')
        col.prop(context.scene,"originalBoneMark",text="original bone name mark")
        col.prop(context.scene,"targetBoneMark",text="target bone name mark")
        col.operator("eerie.mirror_mesh",text="Mirror select arm mesh")
        col.label(text='human armature mirror')
        col.operator("eerie.mirror_armature_on",text="Set armature to mirror editing mode")
        col.operator("eerie.mirror_armature_off",text="Set armature to normal mode")
        col.label(text='convert the vertex groups of the MMD bones to game bones(Experimental)')
        col.operator("eerie.groups_convert",text="Convert")
classes.append(Eerie_PT_view3D)

def register():
    for every_class in classes:
        bpy.utils.register_class(every_class)

def unregister():
    for every_class in classes:
        bpy.utils.unregister_class(every_class)